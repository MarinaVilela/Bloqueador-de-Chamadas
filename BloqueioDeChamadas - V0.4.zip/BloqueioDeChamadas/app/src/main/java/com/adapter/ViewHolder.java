package com.adapter;

import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.TextView;

import com.example.marina.bloqueiodechamadas.R;

/**
 * Created by Marina on 16/12/2017.
 */

public class ViewHolder extends RecyclerView.ViewHolder {

    CardView cardView;
    TextView textView;

    public ViewHolder(View itemView) {
        super(itemView);
        cardView = itemView.findViewById(R.id.card);
        textView = itemView.findViewById(R.id.textNum);

    }
}
