package com.adapter;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.marina.bloqueiodechamadas.R;
import com.marina.model.ListaTelefonesBloqueadosDAO;
import com.marina.model.Telefone;

import java.util.ArrayList;



public class MyAdapter extends RecyclerView.Adapter {

    private Context context;
    private ArrayList<Telefone> arrayTelefone;

    public MyAdapter(Context context, ArrayList<Telefone> arrayTelefone) {
        this.context = context;
        this.arrayTelefone = arrayTelefone;
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        // view recebe o layout dos componentes da lista criados em list_item
        View view = LayoutInflater.from(context).inflate(R.layout.list_item,parent,false);
        ViewHolder viewHolder = new ViewHolder(view);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, final int position) {
        ViewHolder viewHolder = (ViewHolder) holder;

        CardView cardView = viewHolder.cardView;
        TextView textView = viewHolder.textView;

        textView.setText(arrayTelefone.get(position).getNumero());

        cardView.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {

                AlertDialog.Builder builder = new AlertDialog.Builder(context);
                builder.setTitle("Confirmação");
                builder.setMessage("Tem certeza que deseja deletar?");

                builder.setPositiveButton("Sim", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        ListaTelefonesBloqueadosDAO.getInstnace(context).deletar(arrayTelefone.
                                get(position).getNumero());
                        arrayTelefone.remove(arrayTelefone.get(position));
                        notifyDataSetChanged(); // Altera a lista para o usuário depois da remoção
                    }
                });

                builder.setNegativeButton("Não", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {

                    }
                });

                AlertDialog dialog = builder.create();
                dialog.show();

                return false;
            }
        });

    }

    @Override
    public int getItemCount() {
        if (arrayTelefone != null) {
            return arrayTelefone.size();
        }
        return 0;
    }
}
