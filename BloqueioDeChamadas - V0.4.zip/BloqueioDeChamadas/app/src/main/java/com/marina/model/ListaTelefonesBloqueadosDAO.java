package com.marina.model;

import android.content.Context;

import com.j256.ormlite.dao.Dao;
import com.j256.ormlite.dao.DaoManager;
import com.j256.ormlite.stmt.DeleteBuilder;
import com.j256.ormlite.stmt.QueryBuilder;
import com.marina.controller.BancoDeDados;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by Marina on 15/12/2017.
 */

public class ListaTelefonesBloqueadosDAO extends CommonDAO<EntidadeTelefone> {

    private static ListaTelefonesBloqueadosDAO mInstnace;

    public static ListaTelefonesBloqueadosDAO getInstnace(Context context){
        if(mInstnace == null){
            mInstnace = new ListaTelefonesBloqueadosDAO(context);
        }
        return mInstnace;
    }

    public ListaTelefonesBloqueadosDAO(Context context) {
        super(context, EntidadeTelefone.class);
    }


   public boolean existeNumero(String numero){
       ArrayList<EntidadeTelefone> arrayList = new ArrayList<>();
        try{
            QueryBuilder<EntidadeTelefone, Integer> queryBuilder = dao.queryBuilder();
            queryBuilder.where().eq("telefone",numero);
            arrayList = (ArrayList<EntidadeTelefone>) dao.query(queryBuilder.prepare());
        }catch (Exception e){
            e.printStackTrace();
        }
        return (arrayList.size() > 0);
   }



    public void deletar(String numero) {
        try {
            DeleteBuilder<EntidadeTelefone, Integer> deleteBuilder = dao.deleteBuilder();
            deleteBuilder.where().eq("telefone",numero);
            dao.delete(deleteBuilder.prepare());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
