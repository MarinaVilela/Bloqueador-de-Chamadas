package com.marina.model;

import com.j256.ormlite.field.DatabaseField;
import com.j256.ormlite.table.DatabaseTable;

/**
 * Created by Marina on 16/12/2017.
 */
@DatabaseTable(tableName = "telefone")
public class EntidadeTelefone {

    //Classe definida como tabela -> Apenas uma coluna

    // Id com clto incremento
    @DatabaseField(columnName = "id", generatedId = true)
    private int id;

    @DatabaseField(columnName = "telefone", canBeNull = false)
    private String telefone;

    public EntidadeTelefone() {

    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }
}
