package com.marina.controller;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.telephony.TelephonyManager;


import com.android.internal.telephony.ITelephony;
import com.marina.model.ListaTelefonesBloqueadosDAO;

import java.lang.reflect.Method;


public class Bloqueadora extends BroadcastReceiver {

    private String mNumber;

    @Override
    public void onReceive(Context context, Intent intent) {
        if (!intent.getAction().equals("android.intent.action.PHONE_STATE")) {
            return;
        }else {
            mNumber = intent.getStringExtra(TelephonyManager.EXTRA_INCOMING_NUMBER);
            if(ListaTelefonesBloqueadosDAO.getInstnace(context).existeNumero(mNumber)){
                disconnectPhoneItelephony(context);
            }
        }
    }

    @SuppressWarnings({ "rawtypes", "unchecked" })
    private void disconnectPhoneItelephony(Context context) {
        ITelephony telephonyService;
        TelephonyManager telephony = (TelephonyManager)
                context.getSystemService(Context.TELEPHONY_SERVICE);
        try {
            Class c = Class.forName(telephony.getClass().getName());
            Method m = c.getDeclaredMethod("getITelephony");
            m.setAccessible(true);
            telephonyService = (ITelephony) m.invoke(telephony);
            telephonyService.endCall();
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }

}
