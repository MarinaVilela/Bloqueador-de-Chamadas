package com.marina.controller;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;

import com.j256.ormlite.android.apptools.OrmLiteSqliteOpenHelper;
import com.j256.ormlite.support.ConnectionSource;
import com.j256.ormlite.table.TableUtils;
import com.marina.model.EntidadeTelefone;


public class BancoDeDados<E> extends OrmLiteSqliteOpenHelper{

    public BancoDeDados(Context context) {
        super(context, "sistema.db", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase banco, ConnectionSource src) {
        try {
            TableUtils.createTable(src, EntidadeTelefone.class);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    @Override
    public void onUpgrade(SQLiteDatabase banco, ConnectionSource src, int versaoAntiga, int novaVersao) {
        try {
            TableUtils.dropTable(src, EntidadeTelefone.class, true);
            onCreate(banco, src);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void close() {
        super.close();
    }
}
