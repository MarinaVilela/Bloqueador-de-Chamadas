package com.marina.model;

import android.content.Context;

import com.j256.ormlite.dao.Dao;
import com.j256.ormlite.dao.DaoManager;
import com.marina.controller.BancoDeDados;

import java.util.ArrayList;
import java.util.List;


public abstract class CommonDAO<E> extends BancoDeDados<E> {

    protected Dao<E, Integer> dao;
    private Class<E> type;

    public CommonDAO(Context context, Class<E> type) {
        super(context);
        this.type = type;
        setDao();
    }


    protected void setDao() {
        try{
            dao = DaoManager.createDao(getConnectionSource(), type);
        }catch(Exception e){
            e.printStackTrace();
        }
    }

    public ArrayList<E> getAll() {
        ArrayList<E> arrayList = new ArrayList<>();
        try {
            arrayList = (ArrayList<E>) dao.queryForAll();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return arrayList;
    }

    public void cadastrar(E obj) {
        try {
             dao.createIfNotExists(obj);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
