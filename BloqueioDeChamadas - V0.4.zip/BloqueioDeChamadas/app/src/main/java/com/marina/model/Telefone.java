package com.marina.model;

/**
 * Created by Marina on 15/12/2017.
 */

public class Telefone {

    private String numero;

    public String getNumero() {
        return numero;
    }

    public void setNumero(String numero) {
        this.numero = numero;
    }
}
