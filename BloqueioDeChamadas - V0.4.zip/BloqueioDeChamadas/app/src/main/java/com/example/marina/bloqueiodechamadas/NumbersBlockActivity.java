package com.example.marina.bloqueiodechamadas;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.Button;

import com.adapter.MyAdapter;
import com.marina.model.EntidadeTelefone;
import com.marina.model.ListaTelefonesBloqueadosDAO;
import com.marina.model.Telefone;

import java.util.ArrayList;

public class NumbersBlockActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private ArrayList<Telefone> telefones;
    private MyAdapter adapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_numbers_block);

        Button botao = (Button) findViewById(R.id.btnNovo);

        telefones = new ArrayList<>();

        adapter = new MyAdapter(this,telefones);

        recyclerView = (RecyclerView) findViewById(R.id.recycleListView);
        recyclerView.setAdapter(adapter);
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        botao.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(NumbersBlockActivity.this, CreateActivity.class);
                startActivity(i);
            }
        });
    }


    @Override
    protected void onResume() {
        super.onResume();
        ArrayList<EntidadeTelefone> entidadeTelefones = (ArrayList<EntidadeTelefone>)
                ListaTelefonesBloqueadosDAO.getInstnace(this).getAll();
        telefones.clear();
        for(EntidadeTelefone e: entidadeTelefones){
            Telefone telefone = new Telefone();
            telefone.setNumero(e.getTelefone());
            telefones.add(telefone);
        }
        adapter.notifyDataSetChanged();
    }
}
